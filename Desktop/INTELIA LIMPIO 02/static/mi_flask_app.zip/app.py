from flask import Flask, render_template, send_from_directory

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('agendas/visor_agenda.html')

@app.route('/agendas')
def agendas():
    return render_template('agendas/visor_agenda.html')

@app.route('/citas')
def citas():
    return render_template('citas/visor_citas.html')

@app.route('/clientes')
def clientes():
    return render_template('clientes/visor_clientes.html')

@app.route('/diagnostico')
def diagnostico():
    return render_template('diagnostico/ficha_diagnostico.html')

@app.route('/facturacion')
def facturacion():
    return render_template('facturacion/plantilla_factura.html')

@app.route('/incidencias')
def incidencias():
    return render_template('incidencias/visor_incidencias.html')

@app.route('/ordenes')
def ordenes():
    return render_template('ordenes/ordenes.html')

@app.route('/presupuestos')
def presupuestos():
    return render_template('presupuestos/visor_presupuestos.html')

@app.route('/recepcion')
def recepcion():
    return render_template('recepcion/recepcion.html')

@app.route('/stock')
def stock():
    return render_template('stock/modal_stock.html')

@app.route('/trabajos_pendientes')
def trabajos_pendientes():
    return render_template('trabajos_pendientes/plantilla_trabajo.html')

@app.route('/usuarios')
def usuarios():
    return render_template('usuarios/visor_usuarios.html')

@app.route('/vehiculos')
def vehiculos():
    return render_template('vehiculos/vehiculos.html')

@app.route('/data/agendas/<path:filename>')
def agendas_data(filename):
    return send_from_directory('static/data/agendas', filename)

if __name__ == '__main__':
    app.run(debug=True)
