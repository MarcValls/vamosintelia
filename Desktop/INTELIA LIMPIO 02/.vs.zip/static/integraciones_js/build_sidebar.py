import os

# Archivo con el panel lateral (solo el HTML del menú lateral)
SIDEBAR_FILE = 'sidebar.html'

# Carpeta donde están tus módulos HTML (ajusta si es necesario)
HTML_DIR = './static'

# Lee el sidebar una vez
with open(SIDEBAR_FILE, 'r', encoding='utf-8') as f:
    sidebar_html = f.read()

# Procesa cada archivo HTML
for filename in os.listdir(HTML_DIR):
    if filename.endswith('.html') and filename != 'panel.html':
        path = os.path.join(HTML_DIR, filename)
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        # Reemplaza el marcador <!--#SIDEBAR#--> por el sidebar real
        new_content = content.replace('<!--#SIDEBAR#-->', sidebar_html)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"Sidebar insertado en {filename}")

print("Sidebar insertado en todos los módulos.")
