// panel.js: carga sidebar SPA
fetch('panel.html')
  .then(res => res.text())
  .then(html => {
    const temp = document.createElement('div');
    temp.innerHTML = html;
    const panel = temp.querySelector('.sidebar');
    if(panel && document.getElementById('sidebar')) {
      document.getElementById('sidebar').innerHTML = panel.outerHTML;
      // Enlaces SPA (opcional)
      document.querySelectorAll('#sidebar a[href$=".html"]').forEach(link => {
        link.addEventListener('click', function(e) {
          e.preventDefault();
          const modulo = link.getAttribute('href').replace('.html','');
          if(typeof cargarVistaSPA === 'function') {
            cargarVistaSPA(modulo);
          } else {
            window.location.href = link.getAttribute('href');
          }
        });
      });
    }
  });
